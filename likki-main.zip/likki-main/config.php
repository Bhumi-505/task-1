<?php
  $host = "localhost";
  $dbUsername = "root";
  $dbPassword = "";
  $dbName = "users";
  $mysqli = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
?>